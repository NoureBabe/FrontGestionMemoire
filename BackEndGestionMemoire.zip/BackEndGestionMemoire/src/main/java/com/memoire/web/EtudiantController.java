package com.memoire.web;

import com.memoire.dao.SujetRepository;
import com.memoire.entity.*;
import com.memoire.service.AccountService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EtudiantController {
    @Autowired

private AccountService accountService;
    @Autowired
    SujetRepository sujetRepository;
        @PostMapping("/ProposeSujetParGrp")
        public Sujet ProposeSujetParGrp(@RequestBody EtudiantForme etudiantForme){
            return  accountService.ProposeSujetParGrp(etudiantForme.getTitreSujet(),etudiantForme.getNomEntreprice(),etudiantForme.getIdGrp());

        }
    @GetMapping ("/ListeSujetPropose")
public List<Sujet>ListeSujet(){
            return sujetRepository.findAll();
}
}
@Data
class  EtudiantForme {
    private  String titreSujet;
    private String nomEntreprice;
    private String idGrp;
}
