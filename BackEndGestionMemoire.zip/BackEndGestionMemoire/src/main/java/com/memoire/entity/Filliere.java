package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Filliere {
    @Id
    private  String nomfilliere;
    @OneToMany
    private Collection<Sujet> sujets = new ArrayList<>();
    @ManyToOne
    @JoinColumn(name = "cordinateur_filliere")
    private Cordinateur cordinateur;
}
