package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Etudiant implements Serializable{
	@Id
	private String matriculeetudiant;
	private String nom;
	private String prenom;
	@ManyToOne
	@JoinColumn(name = "compte")
	private User user;
}

