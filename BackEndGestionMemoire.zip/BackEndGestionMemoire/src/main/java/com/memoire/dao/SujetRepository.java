package com.memoire.dao;

import com.memoire.entity.Sujet;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import java.util.List;
@RepositoryRestResource
public interface SujetRepository  extends JpaRepository<Sujet, String> {
    public Sujet findBytitreSujet(String titreSujet);
//    @RestResource(path = "/ByTitreSujet")
//    public Page<Sujet> findBytitreSujet(@Param("tr") String tr, Pageable pageable);

    @RestResource(path = "/BytitreSujetContains")
    List<Sujet> findBytitreSujetContains( @Param("mc") String mc);
    @RestResource(path = "/BytitreSujetContainspage")
    Page<Sujet> findBytitreSujetContains( @Param("mc") String mc,Pageable pageable);
}
