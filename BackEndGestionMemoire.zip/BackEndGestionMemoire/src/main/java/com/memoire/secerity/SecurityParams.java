package com.memoire.secerity;

public interface SecurityParams {
    public  static  final String JWT_HEADER_NAME ="Authorization";
    public  static  final  String SECRET ="ediyebabbeahmed@gmail.com";
    public  static  final String HEADER_PREFIX ="Bearer ";
    public  static final  long EXPIRATION = 15*24*3600*1000;

}
