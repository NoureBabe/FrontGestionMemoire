package com.memoire.service;

import com.memoire.dao.*;
import com.memoire.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.xml.crypto.Data;
import java.util.Date;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {
    @Autowired
    ParamatrageAnneeRepository paramatrageAnneeRepository;
    @Autowired
    ParamatragePeriodeProposeRepository paramatragePeriodeProposeRepository;
    @Autowired


    private SujetRepository sujetRepository;
    @Autowired
    JuryRepository juryRepository;
    @Autowired

    EntrepriseRepository entrepriseRepository;
    private UserRepository userRepository;
    @Autowired
    private EtudiantRepository etudiantRepository;
    @Autowired
    private GroupRepository groupRepository;
    @Autowired
    private EnsigniantRepository ensigniantRepository;
    @Autowired
    private  FilliereRepository filliereRepository;
    @Autowired
    //private CordinateurRepository cordinateurRepository;
    private RoleRepository roleRepoitory;
    @Autowired
    DepartementRepository departementRepository;
    private BCryptPasswordEncoder bCryptPasswordEncoder;


    public AccountServiceImpl(UserRepository userRepository, RoleRepository roleRepoitory, BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.userRepository = userRepository;
        this.roleRepoitory = roleRepoitory;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }


    public User saveUser(String username, String password, String confirmedPassword) {
        User user1 = userRepository.findByusername(username);
        if (user1 != null) throw new RuntimeException("Use already exists");
        if (!password.equals(confirmedPassword)) throw new RuntimeException("please confirme your password");
        User user = new User();
        user.setUsername(username);
        user.setActived(true);
        user.setPassword(bCryptPasswordEncoder.encode(password));
        userRepository.save(user);
        addRoleToUser(username,"USER");
        return user;
    }
    public Role save (Role role){

        return roleRepoitory.save(role);
    }

    public User loadUsername (String username){
        return userRepository.findByusername(username);
    }

    public void addRoleToUser (String username, String rolename){
        User user = userRepository.findByusername(username);
        Role role = roleRepoitory.findByRoleName(rolename);
        user.getRoles().add(role);

    }

    @Override
    public Etudiant saveEtudint(String matriculeetudiant, String nom, String prenom) {
        Etudiant etudiant1 = etudiantRepository.findByNom(nom);
        if (etudiant1 != null) throw new RuntimeException("etudiant already exists");
        Etudiant etudiant = new Etudiant();
        etudiant.setMatriculeetudiant(matriculeetudiant);
        etudiant.setNom(nom);
        etudiant.setPrenom(prenom);
        etudiantRepository.save(etudiant);
        return etudiant;
    }

    @Override
    public void addEtudiantToCompte(String nom,String username) {
        User user = userRepository.findByusername(username);
        Etudiant etudiant = etudiantRepository.findByNom(nom);
        etudiant.setUser(userRepository.findByusername(username));
        etudiant.setNom(nom);
        user.getEtudiants().add(etudiant);

    }

    @Override
    public void addEnsegniantToCompte(String nomEnseigniant, String username) {
        User user = userRepository.findByusername(username);
        Ensigniant ensigniant = ensigniantRepository.findByNomEnseigniant(nomEnseigniant);
        ensigniant.setUser(userRepository.findByusername(username));
        ensigniant.setNomEnseigniant(nomEnseigniant);
        user.getEnsigniants().add(ensigniant);
    }

    @Override
    public void EffectAnneeToSujet(String anneeEncours, String titreSujet) {
        ParamatrageAnnee paramatrageAnnee = paramatrageAnneeRepository.findByAnneeEncours(anneeEncours);
        Sujet sujet = sujetRepository.findBytitreSujet(titreSujet);
        sujet.setParamatrageAnnee(paramatrageAnneeRepository.findByAnneeEncours(anneeEncours));
        sujet.setTitreSujet(titreSujet);
        paramatrageAnnee.getSujets().add(sujet);
    }

    @Override
    public void EffectPeriodeProposeToSujet(Date periodeProposesujet, String titreSujet) {
        ParamatragePeriodePropose paramatragePeriodePropose = paramatragePeriodeProposeRepository.findByPeriodeProposesujet(periodeProposesujet);
        Sujet sujet = sujetRepository.findBytitreSujet(titreSujet);
        sujet.setParamatragePeriodePropose(paramatragePeriodeProposeRepository.findByPeriodeProposesujet(periodeProposesujet));
        sujet.setTitreSujet(titreSujet);
        paramatragePeriodePropose.getSujets().add(sujet);
    }

    @Override
    public Jury saveJury(String idJury) {
        Jury jury1 = juryRepository.findByIdJury(idJury);
        if (jury1 != null) throw new RuntimeException("jury already exists");
        Jury jury = new Jury();

        jury.setIdJury(idJury);


        juryRepository.save(jury);
        return jury;
    }

    @Override
    public Entreprise SaveEntreprice(String nomEntreprice, String adresse) {
        Entreprise entreprise1 = entrepriseRepository.findByNomEntreprice(nomEntreprice);
//       if (entreprise1 != null) throw new RuntimeException("entreprice already exists");
        Entreprise entreprise = new Entreprise();
        entreprise.setNomEntreprice(nomEntreprice);
        entreprise.setAdresse(adresse);
        entrepriseRepository.save(entreprise);
        return entreprise;}

    @Override
    public ParamatrageAnnee SaveParamatrageAnnee(String anneeEncours) {
        ParamatrageAnnee paramatrageAnnee1 = paramatrageAnneeRepository.findByAnneeEncours(anneeEncours);
        if (paramatrageAnnee1 != null) throw new RuntimeException("anee already exists");
        ParamatrageAnnee paramatrageAnnee = new ParamatrageAnnee();

        paramatrageAnnee.setAnneeEncours(anneeEncours);
        paramatrageAnneeRepository.save(paramatrageAnnee);
        return paramatrageAnnee;
    }

    @Override
    public ParamatragePeriodePropose SavePeriodePropose(Date periodeProposesujet) {
        ParamatragePeriodePropose paramatragePeriodePropose1 = paramatragePeriodeProposeRepository.findByPeriodeProposesujet(periodeProposesujet);
        if (paramatragePeriodePropose1 != null) throw new RuntimeException("ParamatragePeriodePropose already exists");
        ParamatragePeriodePropose paramatragePeriodePropose = new ParamatragePeriodePropose();

        paramatragePeriodePropose.setPeriodeProposesujet(periodeProposesujet);
        paramatragePeriodeProposeRepository.save(paramatragePeriodePropose);
        return paramatragePeriodePropose;
    }


    public Groupe saveGroup(String idGrp, String nomGrp){
        Groupe groupe1 = groupRepository.findByIdGrp(idGrp);
//        if (groupe1 != null) throw new RuntimeException("group already exists");
        Groupe groupe = new Groupe();
        groupe.setIdGrp(idGrp);
        groupe.setNomGrp(nomGrp);
        groupRepository.save(groupe);
        return groupe;

    }

    @Override
    public void addEtudiantToGroup(String nomGrp,String nom) {
        Etudiant etudiant=etudiantRepository.findByNom(nom);
        Groupe groupe=groupRepository.findByIdGrp(nomGrp);
        groupe.getEtudiants().add(etudiant);

    }

    @Override
    public void addEnsegnintToJury(String idJury, String nomEnseigniant) {
        Ensigniant ensigniant=ensigniantRepository.findByNomEnseigniant(nomEnseigniant);
        Jury jury=juryRepository.findByIdJury(idJury);
        jury.getEnsigniants().add(ensigniant);

    }

    @Override
    public Sujet ProposeSujetParGrp(String titreSujet, String nomEntreprice, String idGrp) {
        Sujet sujet1 = sujetRepository.findBytitreSujet(titreSujet);
        if (sujet1 != null) throw new RuntimeException("sujet already exists");
        Sujet sujet = new Sujet();
        sujet.setTitreSujet(titreSujet);
        sujet.setEntreprise(entrepriseRepository.findByNomEntreprice(nomEntreprice));
        sujet.setGroupe(groupRepository.findByIdGrp(idGrp));
        sujet.setValider(false);
        sujetRepository.save(sujet);
        return sujet;
    }
    public Sujet ProposeSujetParEnseigniat(String titreSujet, String nomEntreprice, String nomEnseigniant) {

        Sujet sujet1 = sujetRepository.findBytitreSujet(titreSujet);
        if (sujet1 != null) throw new RuntimeException("sujet already exists");
        Sujet sujet = new Sujet();
        sujet.setTitreSujet(titreSujet);
        sujet.setEntreprise(entrepriseRepository.findByNomEntreprice(nomEntreprice));
//       sujet.setEntreprice_acceuil(Entreprice_acceuil);
        sujet.setEnsigniant(ensigniantRepository.findByNomEnseigniant(nomEnseigniant));
        sujet.setValider(false);
        sujetRepository.save(sujet);
        Sujet sujet2 = sujetRepository.findBytitreSujet(titreSujet);
        Ensigniant ensigniant = ensigniantRepository.findByNomEnseigniant(nomEnseigniant);
        ensigniant.getSujets_proposer().add(sujet2);
        return sujet;
    }

    @Override
    public Ensigniant saveEnsigniant(Long telEnsegniant, String nomEnseigniant, String prenom, String specialiter) {
        Ensigniant enseigniant1 = ensigniantRepository.findByNomEnseigniant(nomEnseigniant);
        if (enseigniant1 != null) throw new RuntimeException("enseigniant already exists");
        Ensigniant ensigniant = new Ensigniant();
        ensigniant.setTelEnsegniant(telEnsegniant);
        ensigniant.setNomEnseigniant(nomEnseigniant);
        ensigniant.setPrenom(prenom);
        ensigniant.setSpecialiter(specialiter);
        ensigniantRepository.save(ensigniant);
        return ensigniant;
    }

    @Override
    public Filliere SaveFillier(String nomfilliere) {
        Filliere filliere1 = filliereRepository.findByNomfilliere(nomfilliere);
        if (filliere1 != null) throw new RuntimeException("filiere already exists");
        Filliere filliere = new Filliere();

        filliere.setNomfilliere(nomfilliere);


        filliereRepository.save(filliere);
        return filliere;
    }

    @Override
    public Departement SaveDepertement(String nomDepartement) {
        Departement departement1 = departementRepository.findByNomDepartement(nomDepartement);
        if (departement1 != null) throw new RuntimeException("departement already exists");
        Departement departement = new Departement();

        departement.setNomDepartement(nomDepartement);


        departementRepository.save(departement);
        return departement;
    }

    @Override
    public void EffectFilterToSujet(String nomfilliere, String titreSujet) {

        Filliere filliere = filliereRepository.findByNomfilliere(nomfilliere);
        Sujet sujet = sujetRepository.findBytitreSujet(titreSujet);
        sujet.setFilliere(filliereRepository.findByNomfilliere(nomfilliere));
        sujet.setTitreSujet(titreSujet);
        filliere.getSujets().add(sujet);
    }

    @Override
    public void EffectdepertementToEnsegniat(String nomDepartement, String nomEnseigniant) {
        Departement departement = departementRepository.findByNomDepartement(nomDepartement);
        Ensigniant ensigniant = ensigniantRepository.findByNomEnseigniant(nomEnseigniant);
        ensigniant.setDepartement(departementRepository.findByNomDepartement(nomDepartement));
        ensigniant.setNomEnseigniant(nomEnseigniant);
        departement.getEnsigniantsapartient().add(ensigniant);
    }


//    @Override
//    public void AddCordinateureToFilliere(long idfilliere, String NonCordinateur) {
//       Cordinateur cordinateur = cordinateurRepository.findByNonCordinateur(NonCordinateur);
//        Filliere filliere = filliereRepository.findByIdfilliere(idfilliere);
//       cordinateur.getFillier_cordone().add(filliere);
//   }
//
////
//   @Override
//  public Cordinateur saveCordinateure(long telEnsegniant, String NonCordinateur) {
//       Cordinateur cordinateur1 = cordinateurRepository.findByNonCordinateur(NonCordinateur);
//       if (cordinateur1 != null) throw new RuntimeException("cordinateur already exists");
//       Cordinateur cordinateur = new Cordinateur();
//        cordinateur.setNonCordinateur(NonCordinateur);
//        cordinateur.setTelEnsegniant(telEnsegniant);
//       cordinateurRepository.save(cordinateurRepository);
//      return cordinateur;
//   }


//    public Groupe saveSujetToGrp(String idGrp,Sujet sujet) {
//        Groupe groupe1 = groupRepository.findByIdGrp(idGrp);
//        if (groupe1 != null) throw new RuntimeException("group already exists");
//        Groupe groupe = new Groupe();
//        groupe.setIdGrp(idGrp);
//        groupe.setSujet(sujet);
//        groupRepository.save(groupe);
//        return groupe;
//    }



}











