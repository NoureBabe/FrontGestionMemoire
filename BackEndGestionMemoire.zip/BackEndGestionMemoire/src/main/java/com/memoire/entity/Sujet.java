package com.memoire.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Sujet implements Serializable {
	@Id
	private String titreSujet;
  private  String description;
  private  String resultats_attendus;
  private String competances_requises;
  private Boolean valider;
  private int nbrEtudiantMin;
  private  int nbrEtudiantMax;

	@OneToOne
//	@JoinColumn(name = "SujetPropose_Groupe")
	private Groupe groupe;
	@ManyToOne
	@JoinColumn(name = "AnneeEncours")
	private ParamatrageAnnee paramatrageAnnee;
//	@ManyToMany(mappedBy = "sujets", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//	Collection<Groupe> sujets = new ArrayList<>();

//@ManyToOne
//	@JoinColumn(name = "nom_filliere")
//	private Filliere filliere;
@ManyToOne
@JoinColumn(name = "cordintereValider")
private Cordinateur cordinateur;
	@ManyToOne
	private Filliere filliere;
@ManyToOne
//@JoinColumn(name = "superviseur")
private Superviseur superviseur;
	@ManyToOne
//	@JoinColumn(name = "entrepriseAcceuill")
	private Entreprise entreprise;

	@ManyToOne
	@JoinColumn(name = "Planning_soutenance")
   private PlanningSoutenance planningSoutenance_soutenance;
	@ManyToOne
	@JoinColumn(name = "nomEnseignatProposer")
	private Ensigniant ensigniant;
	@OneToMany
	private Collection <Fichier> fichiers = new ArrayList<>();
	@ManyToOne
//  @JoinColumn(name = "encad_acadimiquet")
private Encad_acadimique encad_acadimique;
	@ManyToOne
	@JoinColumn(name = "periodePropose")
	private  ParamatragePeriodePropose paramatragePeriodePropose;

	public Entreprise   getEntreprise(){
		return entreprise;
	}
	public   void setEntreprise( Entreprise entreprise){
		this.entreprise=entreprise;
	}
}
