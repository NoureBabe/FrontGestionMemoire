package com.memoire.entity;
//

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Collection;

//
//

//

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Cordinateur extends Ensigniant {
   private String Nomcordinateur;
  @OneToMany
    private Collection<Filliere> fillier_cordone;
  @OneToMany
    private Collection <Cordinateur> sujetValider;
}
//
