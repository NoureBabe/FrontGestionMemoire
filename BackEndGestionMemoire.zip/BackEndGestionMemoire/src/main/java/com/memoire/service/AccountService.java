package com.memoire.service;

import com.memoire.entity.*;
import com.sun.javafx.sg.prism.EffectFilter;
import javafx.scene.effect.Effect;

import javax.xml.crypto.Data;
import java.util.Date;

public  interface AccountService {
	
	public User saveUser(String username,String password,String confirmedPassword);
	public Role save(Role role);
	public User loadUsername(String username);
	public void addRoleToUser(String username ,String roleName);

    public Etudiant saveEtudint(String matriculeetudiant,String nom, String prenom);
    public void addEtudiantToCompte(String nom,String Compte );
    public void addEnsegniantToCompte(String nomEnseigniant,String Compte );
    public Groupe saveGroup(String idGrp, String nomGrp);
    public   Entreprise SaveEntreprice(String nomEntreprice,String adresse);
    public  ParamatrageAnnee SaveParamatrageAnnee(String anneeEncours);
    public  ParamatragePeriodePropose SavePeriodePropose(Date periodeProposesujet);
    public  void addEtudiantToGroup(String idGrp,String nom);
    public  void addEnsegnintToJury(String idJury,String nomEnseigniant);
   public Sujet ProposeSujetParGrp(String titreSujet, String nomEntreprice,String idGrp);
    public Sujet ProposeSujetParEnseigniat(String titreSujet,String nomEnseigniant ,String nomEntreprice );
    public Ensigniant saveEnsigniant(Long telEnsegniant, String nomEnseigniant,String prenom,String specialiter);
    public Filliere SaveFillier(String nomfilliere);
    public Departement SaveDepertement(String nomDepartement);
    public void  EffectFilterToSujet( String nomfilliere,String nomEnseigniant);
    public void  EffectdepertementToEnsegniat( String nomDepartement,String nomEnseigniant);
    public void  EffectAnneeToSujet( String anneeEncours,String titreSujet);
    public void  EffectPeriodeProposeToSujet(Date periodeProposesujet, String titreSujet);
    public  Jury saveJury( String idJury);


    //public  void AddCordinateureToFilliere(long idfilliere, String NonCordinateur);
    //public  Cordinateur saveCordinateure(long telEnsegniant,String NonCordinateur);
}

