//package com.memoire.dao;
//
//import com.memoire.entity.Cordinateur;
//import com.memoire.entity.Ensigniant;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface CordinateurRepository extends JpaRepository<CordinateurRepository, Long> {
//   public Cordinateur findByNomcordinateur(String nomcordinateur);
//}
