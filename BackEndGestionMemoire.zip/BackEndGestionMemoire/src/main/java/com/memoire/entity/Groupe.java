package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Groupe implements Serializable {
	@Id
	private String idGrp;
	private String nomGrp;
//	@OneToOne
//	private Sujet sujet;
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "Demande",
			joinColumns = @JoinColumn(name = "id_grupe"),
			inverseJoinColumns = @JoinColumn(name = "titre_sujet"))
	private Collection<Sujet> sujetsDemender = new ArrayList<>();
	@OneToMany()
	private Collection <Etudiant> etudiants = new ArrayList<>();
}