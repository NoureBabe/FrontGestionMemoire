package com.memoire.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
//@SequenceGenerator(sequenceName="SEQ_INHERITANCE_TABLE_PER_CLASS",
//		name="seqTPC", initialValue=0, allocationSize=1)

public class Ensigniant implements Serializable {
	@Id
//	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqTPC")
	private Long telEnsegniant;
	private String nomEnseigniant, prenom,specialiter;
	@OneToMany
	private Collection<Sujet> sujets_proposer;
@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name="nom_departement")
	private Departement departement;
	@ManyToOne
	@JoinColumn(name = "compte")
	private User user;
}





