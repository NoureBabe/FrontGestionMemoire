package com.memoire.web;

import com.memoire.dao.SujetRepository;
import com.memoire.entity.Sujet;
import com.memoire.service.AccountService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public class EnsegniatController {
    @Autowired
    private AccountService accountService;
    @Autowired
    SujetRepository sujetRepository;

    @PostMapping("/ProposeSujetParEnseigniat")
    public Sujet ProposeSujetParGrp(@RequestBody EnseigniantForme enseigniantForme) {
        return accountService.ProposeSujetParEnseigniat(enseigniantForme.getTitreSujet(), enseigniantForme.getNomEntreprice(), enseigniantForme.getNomEnseigniant());

    }

    @GetMapping("/ListeSujetPropose")
    public List<Sujet> ListeSujet() {
        return sujetRepository.findAll();
    }

    @Data
    class EnseigniantForme {
        private String titreSujet;
        private String nomEntreprice;
        private String nomEnseigniant;
    }
}
