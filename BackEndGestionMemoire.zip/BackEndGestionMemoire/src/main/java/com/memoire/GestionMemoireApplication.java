package com.memoire;
import  java.lang.NullPointerException;
import java.util.Date;
import java.util.stream.Stream;

import com.memoire.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.memoire.service.AccountService;

@SpringBootApplication
public class GestionMemoireApplication  {
	@Autowired
	private RepositoryRestConfiguration restConfiguration;


	public static void main(String[] args) {
		SpringApplication.run(GestionMemoireApplication.class, args);
	}
@Bean
CommandLineRunner start(AccountService accontService) {
		return args->{
			restConfiguration.exposeIdsFor(ParamatragePeriodePropose.class);
						restConfiguration.exposeIdsFor(Departement.class);
			restConfiguration.exposeIdsFor(Groupe.class);
			restConfiguration.exposeIdsFor(Etudiant.class);
			restConfiguration.exposeIdsFor(Sujet.class);
			restConfiguration.exposeIdsFor(Ensigniant.class);
			restConfiguration.exposeIdsFor(Entreprise.class);
			restConfiguration.exposeIdsFor(Filliere.class);
			restConfiguration.exposeIdsFor(User.class);
			restConfiguration.exposeIdsFor(ParamatrageAnnee.class);
			accontService.save(new Role(1,"USER"));
			accontService.save(new Role(2,"Etudiant"));
			accontService.save(new Role(3,"Ensigniant"));
			accontService.save(new Role(4,"Cordinateur"));
			Stream.of("ie17623.etu@iscae.mr","cheikh.dhib@iscae.mr","bah.demba@gmil.com","Meimoune").forEach(un->{
				accontService.saveUser(un,"1234","1234");
			});
             accontService.addRoleToUser("ie17623.etu@iscae.mr","Etudiant");

             accontService.addRoleToUser("cheikh.dhib@iscae.mr","Ensigniant");
             accontService.addRoleToUser("cheikh.dhib@iscae.mr","Cordinateur");
			accontService.addRoleToUser("bah.demba@gmil.com","Ensigniant");
			accontService.addRoleToUser("Meimoune","Etudiant");
			accontService.saveEtudint("IP17660","Meimoune","Med salem");
			accontService.saveEtudint("IP17659","Mouna","Isselmou");
			accontService.saveEtudint("IE17623","ediye","babe ahmed");
			accontService.addEtudiantToCompte("ediye","ie17623.etu@iscae.mr");
			accontService.addEtudiantToCompte("Meimoune","Meimoune");

			accontService.saveEnsigniant((long) 3679082,"Moussa","Dembe","Informatique");
			accontService.saveEnsigniant((long) 36119845,"Cheikh ","dhib","Informatique");
			accontService.addEnsegniantToCompte("Cheikh","cheikh.dhib@iscae.mr");
			accontService.SaveDepertement("M.Q.I");
			accontService.EffectdepertementToEnsegniat("M.Q.I","Moussa");
			accontService.EffectdepertementToEnsegniat("M.Q.I","Cheikh");
			accontService.addEnsegniantToCompte("Moussa","bah.demba@gmil.com");

			accontService.saveGroup("g1", "GroupeGestionmemo");
			accontService.saveGroup("g2", "GroupeE_Commerce");
			accontService.saveGroup("g3", "GroupeSUpplyChain");
			accontService.addEtudiantToGroup("g1","ediye");
			accontService.addEtudiantToGroup("g1","meimoune");
			accontService.addEtudiantToGroup("g2","Mouna");
			accontService.addEtudiantToGroup("g3","med");
			accontService.SaveEntreprice("A2","add1");
			accontService.SaveEntreprice("Alpha","add1");
			accontService.SaveEntreprice("SISCAT","add1");
			accontService.SaveEntreprice("Zayed","add1");
			accontService.SaveEntreprice("STM","add1");
			accontService.SaveEntreprice("SMCP","add1");
			accontService.ProposeSujetParGrp("CompangeVaccination","SISCAT","g1");
//			accontService.ProposeSujetParGrp("GestionCabinetMedical","Zayed","g2");
			accontService.ProposeSujetParGrp("SupplyChainMangment","A2","g3");
			accontService.ProposeSujetParEnseigniat("GetionRessource","SMCP", "Moussa");
			accontService.ProposeSujetParEnseigniat("E_Commerce","Alpha","Cheikh");
           //accontService.saveCordinateure(36119845,"Cheikh");
			accontService.SaveFillier("Develeoppment_Informatique");
			accontService.SaveFillier("Gestion");
           // accontService.AddCordinateureToFilliere(1,36119845);
            accontService.EffectFilterToSujet("Develeoppment_Informatique","E_Commerce");
			accontService.EffectFilterToSujet("Develeoppment_Informatique","GetionRessource");
			accontService.EffectFilterToSujet("Develeoppment_Informatique","SupplyChainMangment");
			accontService.EffectFilterToSujet("Develeoppment_Informatique","CompangeVaccination");
//			accontService.saveAnneEncours(2020/2021);
           accontService.SaveParamatrageAnnee("2020-2021");
           accontService.EffectAnneeToSujet("2020-2021","CompangeVaccination");
//			accontService.EffectAnneeToSujet("2020-2021","GestionCabinetMedical");
			accontService.EffectAnneeToSujet("2020-2021","SupplyChainMangment");
			accontService.EffectAnneeToSujet("2020-2021","GetionRessource");
			accontService.EffectAnneeToSujet("2020-2021","E_Commerce");
//		     accontService.SavePeriodePropose( new Date(16-8-2020));
			accontService.saveJury("jery1");
			accontService.saveJury("jery2");
			accontService.saveJury("jery3");
			accontService.saveJury("jery");
			accontService.addEnsegnintToJury("jery1","Moussa");
			accontService.addEnsegnintToJury("jery1","Cheikh");
		};
	}
@Bean
	BCryptPasswordEncoder getBCPE() {
		return new BCryptPasswordEncoder();
	}
}












