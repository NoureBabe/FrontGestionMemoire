package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PlanningSoutenance implements Serializable {
	@Id
	private  Long idPlaning;
	private Date date_du_planning;
	private int salle;
	private Date heure_debut;

	private Date heure_fin;
	@OneToMany
	private Collection<Sujet> sujets;
	@OneToMany
	private Collection<Jury> jury_planning;
}