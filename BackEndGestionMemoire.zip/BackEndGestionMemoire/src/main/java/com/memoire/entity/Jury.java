package com.memoire.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Jury implements Serializable {
	@Id
	private String idJury;
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "date_du_planning")
	private PlanningSoutenance planningSoutenance;
	@OneToMany
	private Collection<Ensigniant> ensigniants  = new ArrayList<>();

}